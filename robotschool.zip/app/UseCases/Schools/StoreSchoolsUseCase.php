<?php

namespace App\UseCases\Schools;

use App\UseCases\Contracts\Schools\StoreSchoolsUseCaseInterface;
use Illuminate\Http\Request;

class StoreSchoolsUseCase implements StoreSchoolsUseCaseInterface
{
public function handle(Request $request):bool
{

}
}
