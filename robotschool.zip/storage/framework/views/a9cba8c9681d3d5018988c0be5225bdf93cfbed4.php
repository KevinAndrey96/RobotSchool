<?php $__env->startSection('content'); ?>

    <?php if(Session::has('updaschoolsuccess')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(Session::get('updaschoolsuccess')); ?>

        </div>
    <?php endif; ?>
    <?php if(Session::has('storeschoolsuccess')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(Session::get('storeschoolsuccess')); ?>

        </div>
    <?php endif; ?>
    <?php if(Session::has('deleschoolsuccess')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(Session::get('deleschoolsuccess')); ?>

        </div>
    <?php endif; ?>
    <div class="card">
        <div class="card-header">
            Colegios
        </div>
        <div class="card-body container-fluid">
            <div class="justify-content-center" >
                <div style="width: 100%; padding-left: -10px;">
                    <div class="col-auto mt-5">
                        <div class="table-responsive">
                            <table id="datatable" class="table table-striped table-hover dt-responsive display nowrap" width="100%" cellspacing="0">
                                <thead class="thead-light">
                                    <tr>
                                        <th style="text-align: center; padding:10px;">Logo</th>
                                        <th style="text-align: center; padding:10px;">Nombre</th>
                                        <th style="text-align: center; padding:10px;">Dirección</th>
                                        <th style="text-align: center; padding:10px;">Ciudad</th>
                                        <th style="text-align: center; padding:10px;">País</th>
                                        <th style="text-align: center; padding:10px;">Estado</th>
                                        <th style="text-align: center; padding:10px;">Acción</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr style="text-align: center; padding:10px;">
                                            <td>
                                                <a class="magnific" href="https://miel.robotschool.co/storage/school_logos/<?php echo e(substr($school->icon_url,20)); ?>">
                                                    <img style="width:200px" class="img-thumbnail" src="https://miel.robotschool.co/storage/school_logos/<?php echo e(substr($school->icon_url,20)); ?>" onError="this.onerror=null;this.src='/assets/images/imagen-fallo.jpg';">
                                                </a>
                                            </td>
                                            <td><?php echo e($school->name); ?></td>
                                            <td><?php echo e($school->address); ?></td>
                                            <td><?php echo e($school->city); ?></td>
                                            <td><?php echo e($school->country); ?></td>
                                            <td>
                                                <?php if($school->is_enable == 1): ?>
                                                    Habilitado
                                                <?php else: ?>
                                                    Deshabilitado
                                                <?php endif; ?>
                                            </td>

                                            <td>
                                                <div style="display:block !important; margin-bottom: 3px;" class="row checkbox">
                                                    <?php if($school->is_enable == 1): ?>
                                                        <input style="width: 50px; height:30px;" data-toggle="toggle"
                                                               id="togglestatus<?php echo e($school->id); ?>" class="form-check-input" type="checkbox" checked onchange="getStatus(<?php echo e($school->id); ?>)">
                                                    <?php else: ?>
                                                        <input style="width: 50px; height:30px;" data-toggle="toggle"
                                                               id="togglestatus<?php echo e($school->id); ?>"  class="form-check-input" type="checkbox" onchange="getStatus(<?php echo e($school->id); ?>)">
                                                    <?php endif; ?>
                                                </div>
                                                <div style="display: inline-block" class="row justify-content-center" class="btn-group" role="group">
                                                    <a href="/schools/edit/<?php echo e($school->id); ?>" style="margin:4px; width:40px;" alt="Editar" class="btn btn-block btn-warning form-control"><i style="color:white" class="far fa-edit"></i></a>
                                                        <form method="POST" action="/schools/delete">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="school_id" value=<?php echo e($school->id); ?>>
                                                                <button style="margin:4px; width:40px !important;" class="btn btn-block btn-danger form-control" title="Borrar" type="submit" onclick="return confirm('¿Está seguro que quiere eliminar este colegio?');"><i class="fas fa-exclamation-triangle"></i></button>
                                                        </form>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>
                            <form id="form-status" name="form-status" method="POST" action="/changeStatusSchool">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" id="id">
                                <input type="hidden" name="status" id="status">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function getStatus(id)
        {
            var toggle = document.getElementById("togglestatus"+id);
            var status = document.getElementById("status");
            var form = document.getElementById("form-status");
            var school_id = document.getElementById("id");

            if (toggle.checked == true) {
                status.value = 1;
            } else {
                status.value = 0;
            }
            school_id.value = id;
            form.submit();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Proyectos Laravel\robotschool\resources\views/Schools/index.blade.php ENDPATH**/ ?>