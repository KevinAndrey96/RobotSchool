<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header">
            Crear aula
        </div>
        <div class="card-body">
            <form method="POST" action="/classrooms/store">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name">Nombre:</label>
                    <input class="form-control" type="text" name="name" id="name" required>
                </div>
                <div class="form-group">
                    <label for="name">Código:</label>
                    <input class="form-control" type="text" name="code" id="code" required>
                </div>
                <div class="form-group">
                    <label for="user_id">Profesor a cargo: </label>
                    <select class="form-control" name="user_id" required>
                        <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($teacher->teacher->school_id == $coordinator->coordinator->school_id): ?>
                                <option value="<?php echo e($teacher->id); ?>"><?php echo e($teacher->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <input style="width:160px; color: white; margin-top:20px; float:right;" class="btn btn-primary" type="submit" value="Crear">
            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Proyectos_laravel\robotschool\resources\views/classrooms/create.blade.php ENDPATH**/ ?>