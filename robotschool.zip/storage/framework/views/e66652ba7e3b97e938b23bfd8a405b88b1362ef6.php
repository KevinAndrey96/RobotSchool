<?php $__env->startSection('content'); ?>
    <?php if(Session::has('transfersError')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(Session::get('transfersError')); ?>

        </div>
    <?php endif; ?>
    <div class="card">
        <div class="card-header">
            Transferencias de estudiantes
        </div>
        <div class="card-body container-fluid">
            <div class="justify-content-center" >
                <div style="width: 100%; padding-left: -10px;">
                    <div class="col-auto mt-5">
                        <form method="POST" action="/studentsClassroomUpdate">
                            <?php echo csrf_field(); ?>
                        <div class="table-responsive">
                                <table id="datatable" class="table table-striped table-hover dt-responsive display nowrap" width="100%" cellspacing="0">
                                    <thead class="thead-light">
                                    <tr>
                                        <th style="text-align: center; padding:10px;">Selección</th>
                                        <th style="text-align: center; padding:10px;">Nombre</th>
                                        <th style="text-align: center; padding:10px;">Aula</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr style="text-align: center; padding:10px;">
                                                <td>
                                                    <input class="form-check-input" type="checkbox" name="studentCheck[]" id="studentCheck<?php echo e($student->id); ?>" value="<?php echo e($student->id); ?>" onclick="getIDS(<?php echo e($student->id); ?>)">
                                                </td>
                                                <td><?php echo e($student->name); ?></td>
                                                <td><?php echo e($student->student->classroom->name); ?></td>
                                            </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <input type="hidden" name="cart" id="cart">

                        </div>
                            <div style="margin-top:30px" class="form-group">
                                <label for="classroom_id"><strong>Seleccione un curso:</strong></label>
                                <select class="form-control" name="classroom_id">
                                    <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($classroom->id); ?>"><?php echo e($classroom->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <input type="submit" style="width:160px; color: white; margin-top:20px; float:right;" class="btn btn-primary" value="Transferir">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        var ids = new Array();

        function getIDS(studentID)
        {
            var box = document.getElementById("studentCheck" + studentID);
            var cart = document.getElementById("cart");
            if (box.checked == true) {
                ids.push(studentID)
            } else {
                var i = ids.indexOf(studentID);
                if ( i !== -1 ) {
                    ids.splice( i, 1 );
                }
            }
            cart.value = ids;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Proyectos_laravel\robotschool\resources\views/students/transfers.blade.php ENDPATH**/ ?>