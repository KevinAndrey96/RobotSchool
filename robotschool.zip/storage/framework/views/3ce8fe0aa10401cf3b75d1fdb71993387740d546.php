<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            Editar estudiante
        </div>
        <div class="card-body">
            <form action="/students/update" method="POST" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="name">Nombre:  </label>
                    <input class="form-control" type="text" name="name" id="name" value="<?php echo e($user->name); ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:  </label>
                    <input class="form-control" type="email" name="email" id="email" value="<?php echo e($user->email); ?>" required>
                </div>
                <div class="form-group">
                    <label for="phone">Teléfono:  </label>
                    <input class="form-control" type="text" name="phone" id="phone" value="<?php echo e($user->phone); ?>" required>
                </div>
                <div class="form-group">
                    <label for="classroom_id">Aula:</label>
                    <select class="form-control" name="classroom_id">
                        <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($user->student->classroom_id == $classroom->id): ?>
                                <option value="<?php echo e($classroom->id); ?>" selected><?php echo e($classroom->name); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($classroom->id); ?>"><?php echo e($classroom->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="password">Contraseña:</label>
                    <input class="form-control" type="password" name="password" id="password">
                </div>
                <input type="hidden" name="user_id" value="<?php echo e($id); ?>">
                <input type="submit" style="width:160px; color: white; margin-top:20px; float:right;" class="btn btn-primary" value="Modificar">
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Proyectos_laravel\robotschool\resources\views/students/edit.blade.php ENDPATH**/ ?>