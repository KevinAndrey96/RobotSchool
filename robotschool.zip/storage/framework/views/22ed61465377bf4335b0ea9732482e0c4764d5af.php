<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header">
            Selección de aula
        </div>
        <div class="card-body">
            <div class="form-group">
                <form method="POST" action="/students/finalSave">
                    <?php echo csrf_field(); ?>
                    <label for="classroom_id">Elija un aula para el estudiante:</label>
                    <select class="form-control" name="classroom_id">
                        <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($classroom->id); ?>"><?php echo e($classroom->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <input type="hidden" name="name" value="<?php echo e($name); ?>">
                    <input type="hidden" name="email" value="<?php echo e($email); ?>">
                    <input type="hidden" name="phone" value="<?php echo e($phone); ?>">
                    <input type="hidden" name="password" value="<?php echo e($password); ?>">
                    <input type="hidden" name="school_id" value="<?php echo e($school_id); ?>">
                    <input style="width:160px; color: white; margin-top:20px; float:right;" type="submit" class="btn btn-primary" value="Crear">
                </form>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Proyectos_laravel\robotschool\resources\views/students/chooseClassroom.blade.php ENDPATH**/ ?>