<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            Editar aula
        </div>
        <div class="card-body">
            <form method="POST" action="/classrooms/update">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name">Nombre:</label>
                    <input class="form-control" type="text" name="name" id="name" value="<?php echo e($classroom->name); ?>" required>
                </div>
                <div class="form-group">
                    <label for="name">Código:</label>
                    <input class="form-control" type="text" name="code" id="code" value="<?php echo e($classroom->code); ?>" required>
                </div>
                <div class="form-group">
                    <label for="user_id">Profesor a cargo: </label>
                    <select class="form-control" name="user_id" required>
                        <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($teacher->teacher->school_id == $coordinator->coordinator->school_id): ?>
                                <?php if($classroom->user_id == $teacher->id): ?>
                                    <option value="<?php echo e($teacher->id); ?>" selected><?php echo e($teacher->name); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($teacher->id); ?>"><?php echo e($teacher->name); ?></option>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <input type="hidden" name="classroom_id" value="<?php echo e($id); ?>">
                <input style="width:160px; color: white; margin-top:20px; float:right;" class="btn btn-primary" type="submit" value="Modificar">
            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Proyectos_laravel\robotschool\resources\views/classrooms/edit.blade.php ENDPATH**/ ?>