@extends('layouts.dashboard')
@section('content')
    <div class="card">
        <div class="card-header">
            Colegios
        </div>
        <div class="card-body container-fluid">
            <div class="justify-content-center" >
                <div style="width: 100%; padding-left: -10px;">
                    <div class="col-auto mt-5">
                        <div class="table-responsive">
                            <table id="datatable" class="table table-striped table-bordered table-hover dt-responsive display nowrap" width="100%" cellspacing="0">
                                <thead class="thead-light">
                                    <tr>
                                        <th style="text-align: center; padding:10px;">Logo</th>
                                        <th style="text-align: center; padding:10px;">Nombre</th>
                                        <th style="text-align: center; padding:10px;">Dirección</th>
                                        <th style="text-align: center; padding:10px;">Ciudad</th>
                                        <th style="text-align: center; padding:10px;">País</th>
                                        <th style="text-align: center; padding:10px;">Estado</th>
                                        <th style="text-align: center; padding:10px;">Acción</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($schools as $school)
                                        <tr style="text-align: center; padding:10px;">
                                            <td>
                                                <a class="magnific" href="https://miel.robotschool.co/storage/school_logos/{{substr($school->icon_url,20)}}">
                                                    <img style="width:200px" class="img-thumbnail" src="https://miel.robotschool.co/storage/school_logos/{{substr($school->icon_url,20)}}" onError="this.onerror=null;this.src='/assets/images/imagen-fallo.jpg';">
                                                </a>
                                            </td>
                                            <td>{{$school->name}}</td>
                                            <td>{{$school->address}}</td>
                                            <td>{{$school->city}}</td>
                                            <td>{{$school->country}}</td>
                                            <td>
                                                @if($school->is_enable == 1)
                                                    Habilitado
                                                @else
                                                    Deshabilitado
                                                @endif
                                            </td>

                                            <td>
                                                <div style="display:block !important; margin-bottom: 3px;" class="row checkbox">
                                                    @if($school->is_enable == 1)
                                                        <input style="width: 50px; height:30px;" data-toggle="toggle"
                                                               id="toggle-two" class="form-check-input" type="checkbox" checked>
                                                    @else
                                                        <input style="width: 50px; height:30px;" data-toggle="toggle"
                                                               id="toggle-two"  class="form-check-input" type="checkbox">
                                                    @endif
                                                </div>
                                                <div style="display: inline-block" class="row justify-content-center" class="btn-group" role="group">
                                                    <a href="/residents/edit/{{$school->id}}" style="margin:4px; width:40px;" alt="Editar" class="btn btn-block btn-warning form-control"><i style="color:white" class="far fa-edit"></i></a>
                                                        <form method="POST" action="/residents/delete">
                                                                @csrf
                                                                <input type="hidden" name="id" value={{ $school->id }}>
                                                                <button style="margin:4px; width:40px !important;" class="btn btn-block btn-danger form-control" title="Borrar" type="submit" onclick="return confirm('Si borra el residente el apartamento de este se reseteara y no tendrá dueño, esta seguro?');"><i class="fas fa-exclamation-triangle"></i></button>
                                                        </form>
                                                </div>
                                            </td>
                                        </tr>
                                        @endforeach
                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
